<?php

include_once QODE_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/panel-area-opener/panel-area-opener.php';
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/panel-area-opener/functions.php';