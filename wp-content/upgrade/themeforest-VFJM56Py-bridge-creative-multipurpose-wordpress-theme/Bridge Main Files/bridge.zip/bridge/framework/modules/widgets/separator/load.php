<?php

include_once QODE_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/separator/separator.php';
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/separator/functions.php';