<?php

include_once QODE_TOURS_CPT_PATH . '/destinations/destinations-register.php';
include_once QODE_TOURS_CPT_PATH . '/destinations/helper-functions.php';