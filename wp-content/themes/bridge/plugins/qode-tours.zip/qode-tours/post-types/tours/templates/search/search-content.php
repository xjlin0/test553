<div class="qode-tours-search-content">
	<div <?php qode_tours_class_attribute($list_classes);?>>
		<div class="qode-tours-row-inner-holder qode-outer-space">
			<?php echo qode_tours_get_search_page_items_loop_html($tours_list, $type); ?>
		</div>
	</div>
</div>