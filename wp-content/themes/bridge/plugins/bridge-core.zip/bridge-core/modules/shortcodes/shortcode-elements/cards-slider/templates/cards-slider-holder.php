<div class="qode-cards-holder">
    <div class="qode-cards-header cards">

    </div>
    <div class="qode-card-panes">
        <?php echo do_shortcode($content); ?>
    </div>
</div>