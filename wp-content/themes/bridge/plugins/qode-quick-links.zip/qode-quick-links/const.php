<?php

define('QODE_QUICK_LINKS_VERSION', '2.1');
define('QODE_QUICK_LINKS_ABS_PATH', dirname(__FILE__));
define('QODE_QUICK_LINKS_REL_PATH', dirname(plugin_basename(__FILE__ )));