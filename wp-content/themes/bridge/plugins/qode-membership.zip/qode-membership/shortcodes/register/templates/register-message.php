<div class="qode-register-notice">
	<h5 class="qode-register-notice-title"><?php echo esc_html($message); ?></h5>
</div>