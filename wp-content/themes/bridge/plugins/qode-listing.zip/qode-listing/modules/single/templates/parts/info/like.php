<?php if( function_exists('bridge_core_like') ) {
    ?>
    <div class="qode-ls-header-info qode-ls-like">
        <?php bridge_core_like(); ?>
    </div>
<?php } ?>