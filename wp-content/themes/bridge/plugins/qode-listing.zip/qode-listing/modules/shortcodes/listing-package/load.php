<?php
if(qode_listing_is_wc_paid_listings_installed()){
   require_once 'listing-package.php';
   require_once 'helper.php';
}