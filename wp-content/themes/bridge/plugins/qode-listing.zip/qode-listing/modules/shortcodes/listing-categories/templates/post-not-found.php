<p class="qode-ls-not-found">
	<?php esc_html_e( 'Sorry, no posts matched your criteria.', 'qode-listing' ); ?>
</p>