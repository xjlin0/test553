<div class="qodef-ci-compare">
    <?php echo qodef_re_get_add_to_compare_list_button($id); ?>
</div>