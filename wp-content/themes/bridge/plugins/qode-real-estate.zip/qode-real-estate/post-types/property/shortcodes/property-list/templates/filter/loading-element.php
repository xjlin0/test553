<div class="qodef-pl-filter-loading">
    <div class="qodef-pl-loading-bounce1"></div>
    <div class="qodef-pl-loading-bounce2"></div>
    <div class="qodef-pl-loading-bounce3"></div>
</div>