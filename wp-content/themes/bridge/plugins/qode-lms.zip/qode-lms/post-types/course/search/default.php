<div class="container">
    <div class="container_inner">
        <?php qode_lms_get_cpt_single_module_template_part( 'search/parts/search-form', 'course', '', $params ); ?>
        <?php qode_lms_get_cpt_single_module_template_part( 'search/parts/loop', 'course', '', $params ); ?>
    </div>
</div>